namespace ProEventos.Domain.Enum
{
    public enum Funcao
    {
        NaoInformado,
        Participante,
        Palestrante
    }
}
