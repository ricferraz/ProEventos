namespace ProEventos.Domain.Enum
{
    public enum Titulo
    {
        NaoInformado,
        Tecnologo,
        Bacharel,
        Especialista,
        PosGraduado,
        Mestrado,
        Doutorado,
        PosDoutorado
    }
}
