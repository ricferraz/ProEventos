export class UserUpdate {
  titulo: string;
  userName: string;
  primeiroNome: string;
  ultimoNome: string;
  email: string;
  phoneNumber: string;
  funcao: string;
  descricao: string;
  password: string;
  token: string;
  imagemURL: string;
}
