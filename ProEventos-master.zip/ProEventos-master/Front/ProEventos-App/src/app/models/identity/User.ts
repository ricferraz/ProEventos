export class User {
  userName: string;
  email: string;
  password: string;
  primeiroNome: string;
  ultimoNome: string;
  token: string;
}
