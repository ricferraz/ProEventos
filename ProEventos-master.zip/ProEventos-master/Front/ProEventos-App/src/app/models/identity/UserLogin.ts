export class UserLogin {
  userName: string;
  password: string;
}
